
import React, { useState } from 'react';
import { Home, Moon, Sun, ChevronLeft, Menu, Cloud, Layout, Zap, Wand2, Loader2, Settings, Crown, Activity } from 'lucide-react';
import { SidebarTab, DocumentSession, ThemeColor, AppSettings } from '../types';
import { generateImageFromPrompt } from '../services/geminiService';

interface SidebarProps {
  user: any;
  activeTab: SidebarTab;
  onTabChange: (tab: SidebarTab) => void;
  isCollapsed: boolean;
  toggleCollapse: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  sessions: DocumentSession[];
  activeSessionId: string;
  onSwitchSession: (id: string) => void;
  onNewSession: () => void;
  onCloseSession: (id: string) => void;
  onLogin: () => void;
  onLogout: () => void;
  onApplyTemplate: (type: 'resume' | 'letter' | 'notes') => void;
  onInsertImage: (url: string) => void;
  toc: any[];
  tone: { tone: string; score: number };
  credits: number;
  onOpenPricing: () => void;
  settings: AppSettings;
  updateSettings: (s: Partial<AppSettings>) => void;
  onAIImageGen?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  user, activeTab, onTabChange, isCollapsed, toggleCollapse, isDarkMode, toggleDarkMode, sessions, activeSessionId, credits, tone, settings, onAIImageGen, onLogin, onOpenPricing
}) => {
  const [imagePrompt, setImagePrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);

  const generateAIImage = async () => {
    if (!imagePrompt.trim() || credits <= 0) return;
    setIsGenerating(true);
    onAIImageGen?.();
    
    try {
      const url = await generateImageFromPrompt(imagePrompt);
      if (url) {
        setGeneratedImageUrl(url);
      }
    } catch (e) {
      console.error("Gemini Image Gen Error", e);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <aside className={`${isCollapsed ? 'w-16' : 'w-72'} h-full bg-[#1A1C1E] border-r border-white/5 flex flex-col transition-all duration-500 ease-in-out z-40 no-print text-white shrink-0`}>
      <div className="p-6 flex items-center justify-between">
        {!isCollapsed && (
          <div className="flex items-center gap-3">
            <div 
              className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-black text-[10px] shadow-[0_0_20_rgba(37,99,235,0.4)]"
              style={{ backgroundColor: settings.branding.primaryColor }}
            >
              {settings.branding.companyName.substring(0, 2).toUpperCase()}
            </div>
            <span className="font-black text-xs uppercase tracking-[0.2em]">{settings.branding.companyName}</span>
          </div>
        )}
        <button onClick={toggleCollapse} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
          {isCollapsed ? <Menu size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>

      {!isCollapsed && (
        <div className="px-6 mb-8">
           <div className="bg-white/5 p-5 rounded-3xl border border-white/10">
              <div className="flex items-center justify-between mb-4">
                 <span className="text-[9px] font-black uppercase tracking-widest opacity-40">Tone Pulse</span>
                 <Activity size={12} className="text-blue-500 animate-pulse" />
              </div>
              <div className="flex items-end justify-between">
                 <h4 className="text-lg font-black">{tone.tone}</h4>
                 <span className="text-[10px] font-mono text-blue-400 font-bold">{tone.score}%</span>
              </div>
              <div className="mt-3 h-1 w-full bg-white/10 rounded-full overflow-hidden">
                 <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${tone.score}%` }} />
              </div>
           </div>
        </div>
      )}

      <nav className="flex-1 flex flex-col gap-1 px-3 overflow-y-auto no-scrollbar">
        <NavButton active={activeTab === SidebarTab.HOME} onClick={() => onTabChange(SidebarTab.HOME)} icon={Home} label="Desktop" isCollapsed={isCollapsed} color={settings.branding.primaryColor} />
        <NavButton active={activeTab === SidebarTab.TEMPLATES} onClick={() => onTabChange(SidebarTab.TEMPLATES)} icon={Layout} label="Library" isCollapsed={isCollapsed} color={settings.branding.primaryColor} />
        <NavButton active={activeTab === SidebarTab.AI_IMAGE} onClick={() => onTabChange(SidebarTab.AI_IMAGE)} icon={Zap} label="AI Lab" isCollapsed={isCollapsed} color={settings.branding.primaryColor} />
        <NavButton active={activeTab === SidebarTab.SETTINGS} onClick={() => onTabChange(SidebarTab.SETTINGS)} icon={Settings} label="Identity" isCollapsed={isCollapsed} color={settings.branding.primaryColor} />
        
        {!isCollapsed && activeTab === SidebarTab.AI_IMAGE && (
          <div className="mt-8 px-2 space-y-4 animate-in fade-in zoom-in-95 duration-500">
             <textarea 
               value={imagePrompt}
               onChange={(e) => setImagePrompt(e.target.value)}
               placeholder="Describe a visualization..." 
               className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-[11px] outline-none h-24 no-scrollbar resize-none"
             />
             <button 
               onClick={generateAIImage} 
               disabled={isGenerating} 
               className="w-full py-3 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl"
               style={{ backgroundColor: settings.branding.primaryColor }}
             >
               {isGenerating ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14}/>} {isGenerating ? 'Synthesizing...' : 'Generate Image'}
             </button>
             {generatedImageUrl && (
               <div className="mt-4 rounded-xl overflow-hidden border border-white/10">
                 <img src={generatedImageUrl} alt="AI Result" className="w-full h-auto object-cover" />
               </div>
             )}
          </div>
        )}
      </nav>

      <div className="p-4 bg-black/20 flex flex-col gap-2">
        <button onClick={toggleDarkMode} className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-white/10 transition-all text-gray-400 hover:text-white">
          {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          {!isCollapsed && <span className="text-xs font-bold">{isDarkMode ? 'Appearance' : 'Obsidian'}</span>}
        </button>
        {!user && <button onClick={onLogin} className="w-full py-3 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl" style={{ backgroundColor: settings.branding.primaryColor }}><Cloud size={14}/> Connect</button>}
      </div>
    </aside>
  );
};

const NavButton = ({ active, onClick, icon: Icon, label, isCollapsed, color }: any) => (
  <button 
    onClick={onClick} 
    className={`flex items-center gap-4 p-3 rounded-xl transition-all ${active ? 'text-white shadow-lg' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
    style={active ? { backgroundColor: color } : {}}
  >
    <Icon size={18} />
    {!isCollapsed && <span className="text-xs font-black uppercase tracking-widest">{label}</span>}
  </button>
);
