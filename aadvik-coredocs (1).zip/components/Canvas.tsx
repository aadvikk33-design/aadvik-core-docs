
import React, { useRef, useState, useEffect } from 'react';
import { AppSettings, UserPresence } from '../types';
import { User, Mail, Calendar, Sparkles, Lock, KeyRound, Languages } from 'lucide-react';
import { getGhostText, getQuickSummary, detectAndTranslate } from '../services/geminiService';

interface CanvasProps {
  content: string;
  onChange: (c: string) => void;
  settings: AppSettings;
  collaborators: UserPresence[];
  userId?: string;
  onCursorMove: (pos: { x: number, y: number }) => void;
  isLocked: boolean;
  onUnlock: (pin: string) => void;
  onTranslationOffer: (translated: string) => void;
  workspaceMemory: string;
}

export const Canvas: React.FC<CanvasProps> = ({ content, onChange, settings, collaborators, userId, onCursorMove, isLocked, onUnlock, onTranslationOffer, workspaceMemory }) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const [ghostText, setGhostText] = useState('');
  const [mentionMenu, setMentionMenu] = useState<{ x: number, y: number } | null>(null);
  const [summaryBubble, setSummaryBubble] = useState<{ x: number, y: number, text: string } | null>(null);
  const [pin, setPin] = useState('');
  const ghostTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== content) {
      const selection = window.getSelection();
      let range: Range | null = null;
      if (selection && selection.rangeCount > 0) range = selection.getRangeAt(0).cloneRange();
      editorRef.current.innerHTML = content;
      if (range && selection) {
        try { selection.removeAllRanges(); selection.addRange(range); } catch(e) {}
      }
    }
  }, [content]);

  // Enterprise Interceptor: Detect foreign language on paste
  const handlePaste = async (e: React.ClipboardEvent) => {
    const pastedText = e.clipboardData.getData('text');
    if (pastedText.length > 20) {
      // Background check for language
      detectAndTranslate(pastedText).then(result => {
        if (result.isForeign && result.translated) {
          onTranslationOffer(result.translated);
        }
      });
    }
  };

  const handleSelection = async () => {
    const selection = window.getSelection();
    const selectedText = selection?.toString().trim();
    if (selectedText && selectedText.length > 150) {
      const range = selection?.getRangeAt(0);
      const rect = range?.getBoundingClientRect();
      const editorRect = editorRef.current?.getBoundingClientRect();
      if (rect && editorRect) {
        setSummaryBubble({ x: rect.left - editorRect.left, y: rect.top - editorRect.top - 40, text: "Synthesizing Gist..." });
        const gist = await getQuickSummary(selectedText);
        setSummaryBubble({ x: rect.left - editorRect.left, y: rect.top - editorRect.top - 40, text: gist });
      }
    } else {
      setSummaryBubble(null);
    }
  };

  const fetchGhostText = async (text: string) => {
    if (text.length < 5) return;
    // Utilize workspace memory to provide smarter completions across documents
    const suggestion = await getGhostText(text.slice(-150), workspaceMemory);
    setGhostText(suggestion);
  };

  const handleInput = (e: React.FormEvent<HTMLDivElement>) => {
    const newContent = e.currentTarget.innerHTML;
    onChange(newContent);
    setGhostText('');
    const text = e.currentTarget.innerText;
    if (ghostTimeoutRef.current) clearTimeout(ghostTimeoutRef.current);
    ghostTimeoutRef.current = setTimeout(() => fetchGhostText(text), 1500);

    // Mention Detection
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const textBefore = range.startContainer.textContent?.slice(0, range.startOffset) || '';
      if (textBefore.endsWith('@')) {
        const rect = range.getBoundingClientRect();
        const editorRect = editorRef.current?.getBoundingClientRect();
        if (editorRect) setMentionMenu({ x: rect.left - editorRect.left, y: rect.top - editorRect.top + 24 });
      } else {
        setMentionMenu(null);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Tab' && ghostText) {
      e.preventDefault();
      document.execCommand('insertHTML', false, ghostText);
      setGhostText('');
    }
  };

  if (isLocked) {
    return (
      <div className="w-full max-w-[210mm] mx-auto relative h-[80vh] flex items-center justify-center">
         <div className="absolute inset-0 bg-white/20 backdrop-blur-3xl rounded-[48px] border border-white/40 shadow-2xl z-10" />
         <div className="relative z-20 text-center space-y-10 animate-in zoom-in-95 duration-700">
            <div className="w-24 h-24 bg-[var(--primary)] rounded-[32px] flex items-center justify-center text-white mx-auto shadow-2xl shadow-blue-500/20">
               <Lock size={40} />
            </div>
            <div className="space-y-3">
               <h2 className="text-2xl font-black uppercase tracking-[0.4em] text-slate-900">Vault Protocol</h2>
               <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Restricted Enterprise Artifact</p>
            </div>
            <div className="flex gap-4 justify-center">
               {[0,1,2,3].map(i => (
                 <div key={i} className={`w-14 h-20 rounded-2xl border-4 flex items-center justify-center text-3xl font-black transition-all duration-300 ${pin.length > i ? 'border-[var(--primary)] bg-blue-50 scale-110 shadow-lg' : 'border-gray-100 bg-gray-50'}`}>
                    {pin.length > i ? '•' : ''}
                 </div>
               ))}
            </div>
            <div className="grid grid-cols-3 gap-4 max-w-[280px] mx-auto">
               {[1,2,3,4,5,6,7,8,9,'C',0,'OK'].map(n => (
                 <button 
                  key={n} 
                  onClick={() => {
                    if (n === 'C') setPin('');
                    else if (n === 'OK') onUnlock(pin);
                    else if (pin.length < 4) setPin(p => p + n);
                  }}
                  className={`w-full h-14 rounded-2xl text-[14px] font-black shadow-sm hover:shadow-xl active:scale-95 transition-all ${n === 'OK' ? 'bg-[var(--primary)] text-white' : 'bg-white text-slate-800 border border-gray-100'}`}
                 >
                   {n}
                 </button>
               ))}
            </div>
         </div>
      </div>
    );
  }

  return (
    <div className="relative w-full max-w-[210mm] mx-auto">
      {/* Remote Cursors */}
      <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden">
        {collaborators.filter(c => c.uid !== userId && c.cursorPos).map(c => (
          <div key={c.uid} className="absolute transition-all duration-200 ease-out" style={{ left: c.cursorPos?.x, top: c.cursorPos?.y }}>
            <div className="w-[3px] h-6 shadow-sm" style={{ backgroundColor: c.color }} />
            <div className="absolute top-[-22px] left-0 px-3 py-1 rounded-full text-[9px] font-black text-white whitespace-nowrap shadow-xl" style={{ backgroundColor: c.color }}>
              {c.name.split(' ')[0]}
            </div>
          </div>
        ))}
      </div>

      <div 
        ref={editorRef} 
        contentEditable 
        onInput={handleInput} 
        onKeyDown={handleKeyDown}
        onMouseUp={handleSelection}
        onPaste={handlePaste}
        className={`a4-page transition-all duration-700 size-${settings.pageSize} editor-body`}
        style={{ fontFamily: settings.fontFamily, fontSize: '11pt' }}
      />

      {/* Summary Bubble */}
      {summaryBubble && (
        <div 
          className="absolute z-[500] bg-slate-900 text-white px-6 py-5 rounded-[24px] shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-300 max-w-sm border border-white/10"
          style={{ left: summaryBubble.x, top: summaryBubble.y }}
        >
           <div className="flex items-center gap-3 mb-3">
              <Sparkles size={16} className="text-blue-400" />
              <span className="text-[10px] font-black uppercase tracking-widest text-blue-400">AI Intelligence Pulse</span>
           </div>
           <p className="text-[12px] font-medium leading-relaxed italic opacity-90">{summaryBubble.text}</p>
        </div>
      )}

      {/* Ghost Text Layer */}
      {ghostText && editorRef.current && (
        <div className="absolute pointer-events-none opacity-20 text-[var(--primary)] whitespace-pre-wrap select-none" style={{
          left: (window.getSelection()?.getRangeAt(0).getBoundingClientRect().left || 0) - (editorRef.current?.getBoundingClientRect().left || 0),
          top: (window.getSelection()?.getRangeAt(0).getBoundingClientRect().top || 0) - (editorRef.current?.getBoundingClientRect().top || 0),
          fontFamily: settings.fontFamily, fontSize: '11pt'
        }}>
          {ghostText}
        </div>
      )}

      {/* Mention Menu */}
      {mentionMenu && (
        <div className="absolute z-[200] w-72 bg-white rounded-[32px] shadow-2xl border border-gray-100 p-3 animate-in fade-in zoom-in-95 duration-300" style={{ left: mentionMenu.x, top: mentionMenu.y }}>
          <div className="px-5 py-3 text-[9px] font-black uppercase tracking-widest text-slate-400">Strategic Entity Mapping</div>
          <MentionItem icon={User} label="Project Lead" sub="Lead Architect" />
          <MentionItem icon={Mail} label="Stakeholder Review" sub="admin@coredocs.io" />
          <MentionItem icon={Calendar} label="Phase Transition" sub="Upcoming Deadline" />
        </div>
      )}
    </div>
  );
};

const MentionItem: React.FC<{ icon: any, label: string, sub: string }> = ({ icon: Icon, label, sub }) => (
  <button className="w-full flex items-center gap-4 p-3 hover:bg-slate-50 rounded-2xl transition-all group">
    <div className="p-3 bg-gray-50 group-hover:bg-blue-600 text-slate-400 group-hover:text-white rounded-xl transition-all shadow-sm"><Icon size={16}/></div>
    <div className="text-left">
      <p className="text-[12px] font-black text-slate-900">{label}</p>
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{sub}</p>
    </div>
  </button>
);
