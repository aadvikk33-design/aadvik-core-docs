
import React, { useState, useEffect, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, Monitor, Layout, Download, Palette, Type, Clock } from 'lucide-react';
import { Slide, PresentationTheme } from '../types';

interface PresentationOverlayProps {
  slides: Slide[];
  onClose: () => void;
  docTitle: string;
}

export const PresentationOverlay: React.FC<PresentationOverlayProps> = ({ slides, onClose, docTitle }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [theme, setTheme] = useState<PresentationTheme>('corporate');
  const [presenterMode, setPresenterMode] = useState(false);
  const [startTime] = useState(Date.now());
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const elapsed = Math.floor((now - startTime) / 1000);
  const formatTime = (s: number) => `${Math.floor(s/60)}:${(s%60).toString().padStart(2, '0')}`;

  const next = useCallback(() => setCurrentIdx(p => Math.min(slides.length - 1, p + 1)), [slides.length]);
  const prev = useCallback(() => setCurrentIdx(p => Math.max(0, p - 1)), []);

  useEffect(() => {
    const handleKeys = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') next();
      if (e.key === 'ArrowLeft') prev();
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeys);
    return () => window.removeEventListener('keydown', handleKeys);
  }, [next, prev, onClose]);

  const exportToPPTX = () => {
    // @ts-ignore
    const pptx = new PptxGenJS();
    pptx.title = docTitle;
    
    slides.forEach(s => {
      const slide = pptx.addSlide();
      slide.addText(s.title, { x: 0.5, y: 0.5, w: '90%', fontSize: 32, bold: true, color: '0078D4' });
      slide.addText(s.content.join('\n'), { x: 0.5, y: 1.5, w: '90%', fontSize: 18, bullet: true });
      slide.addNotes(s.notes);
    });

    pptx.writeFile({ fileName: `${docTitle}.pptx` });
  };

  const themes: Record<PresentationTheme, string> = {
    corporate: 'bg-white text-slate-900',
    minimalist: 'bg-[#0f1113] text-gray-200',
    creative: 'bg-gradient-to-br from-indigo-900 via-slate-900 to-black text-white'
  };

  const currentSlide = slides[currentIdx];

  return (
    <div className={`fixed inset-0 z-[1000] flex flex-col transition-all duration-700 ${themes[theme]}`}>
      {/* Header */}
      <div className="h-16 px-8 flex items-center justify-between border-b border-white/10 shrink-0">
        <div className="flex items-center gap-4">
          <Monitor size={18} className="text-blue-500" />
          <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Presentation: {docTitle}</span>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 bg-black/10 rounded-full p-1">
            {(['corporate', 'minimalist', 'creative'] as PresentationTheme[]).map(t => (
              <button 
                key={t}
                onClick={() => setTheme(t)}
                className={`w-6 h-6 rounded-full border-2 transition-all ${theme === t ? 'border-blue-500 scale-110' : 'border-transparent opacity-40 hover:opacity-100'}`}
                style={{ backgroundColor: t === 'corporate' ? '#0078D4' : t === 'minimalist' ? '#1A1C1E' : '#7c3aed' }}
              />
            ))}
          </div>
          
          <button onClick={() => setPresenterMode(!presenterMode)} className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${presenterMode ? 'bg-blue-600 text-white' : 'bg-white/5 hover:bg-white/10'}`}>
            <Layout size={14}/> Presenter View
          </button>
          
          <button onClick={exportToPPTX} className="flex items-center gap-2 px-4 py-1.5 bg-green-600 text-white rounded-lg text-[9px] font-black uppercase tracking-widest shadow-lg haptic-btn">
            <Download size={14}/> PPTX
          </button>

          <div className="w-[1px] h-6 bg-white/10" />
          
          <button onClick={onClose} className="p-2 hover:bg-red-500/10 rounded-full transition-colors"><X size={20}/></button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Slide Area */}
        <div className={`flex-1 flex items-center justify-center p-20 transition-all duration-500 ${presenterMode ? 'max-w-[70%]' : 'max-w-full'}`}>
          <div className="w-full max-w-4xl animate-in fade-in slide-in-from-bottom-8 duration-500" key={currentIdx}>
            <h1 className={`text-6xl font-black mb-12 tracking-tight ${theme === 'corporate' ? 'text-blue-600' : ''}`}>
              {currentSlide.title}
            </h1>
            <ul className="space-y-8">
              {currentSlide.content.map((point, i) => (
                <li key={i} className="flex gap-6 text-2xl font-medium leading-relaxed opacity-90">
                  <span className="text-blue-500 mt-2">•</span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Presenter Sidebar */}
        {presenterMode && (
          <div className="w-[30%] bg-black/20 backdrop-blur-xl border-l border-white/10 flex flex-col animate-in slide-in-from-right-10 duration-500">
            <div className="p-8 border-b border-white/10">
              <div className="flex items-center justify-between mb-4">
                 <span className="text-[9px] font-black uppercase tracking-widest opacity-40">Presenter Console</span>
                 <div className="flex items-center gap-2 text-blue-400">
                    <Clock size={12}/>
                    <span className="text-xs font-mono font-bold">{formatTime(elapsed)}</span>
                 </div>
              </div>
              <h4 className="text-sm font-bold opacity-60">Up Next: {slides[currentIdx+1]?.title || 'End of Show'}</h4>
            </div>
            
            <div className="flex-1 p-8 overflow-y-auto no-scrollbar">
              <h5 className="text-[10px] font-black uppercase tracking-widest text-blue-500 mb-4">Speaker Notes</h5>
              <p className="text-lg leading-relaxed font-medium text-gray-300 italic">
                {currentSlide.notes}
              </p>
            </div>

            <div className="p-8 border-t border-white/10">
               <div className="flex justify-between gap-4">
                  <button onClick={prev} disabled={currentIdx === 0} className="flex-1 py-4 bg-white/5 hover:bg-white/10 rounded-2xl flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest disabled:opacity-20 transition-all">
                    <ChevronLeft size={16}/> Back
                  </button>
                  <button onClick={next} disabled={currentIdx === slides.length - 1} className="flex-1 py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest disabled:opacity-20 transition-all">
                    Next <ChevronRight size={16}/>
                  </button>
               </div>
            </div>
          </div>
        )}
      </div>

      {/* Progress Bar */}
      <div className="h-1.5 w-full bg-white/5 relative">
        <div 
          className="h-full bg-blue-500 transition-all duration-300" 
          style={{ width: `${((currentIdx + 1) / slides.length) * 100}%` }} 
        />
      </div>

      {/* Footer Controls */}
      {!presenterMode && (
        <div className="h-16 px-12 flex items-center justify-between bg-black/5 shrink-0">
          <span className="text-[9px] font-black uppercase tracking-widest opacity-40">Slide {currentIdx + 1} / {slides.length}</span>
          <div className="flex items-center gap-6">
            <button onClick={prev} className="p-2 hover:bg-white/10 rounded-full"><ChevronLeft/></button>
            <button onClick={next} className="p-2 hover:bg-white/10 rounded-full"><ChevronRight/></button>
          </div>
        </div>
      )}
    </div>
  );
};
