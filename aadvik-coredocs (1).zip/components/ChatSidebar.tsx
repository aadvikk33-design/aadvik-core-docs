
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, MessageSquare } from 'lucide-react';
import { ChatMessage } from '../types';

interface ChatSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onSend: (text: string) => void;
  currentUser: any;
}

export const ChatSidebar: React.FC<ChatSidebarProps> = ({ isOpen, onClose, messages, onSend, currentUser }) => {
  const [input, setInput] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    onSend(input);
    setInput('');
  };

  return (
    <div className={`fixed top-0 right-0 h-full bg-white shadow-2xl transition-all duration-500 ease-in-out z-[150] flex flex-col ${isOpen ? 'w-80 translate-x-0' : 'w-0 translate-x-full'}`}>
      <div className="p-6 border-b flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <MessageSquare size={18} className="text-blue-600" />
          <span className="text-[10px] font-black uppercase tracking-widest">Collab Chat</span>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full"><X size={18}/></button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {messages.map((m) => (
          <div key={m.id} className={`flex flex-col ${m.senderId === currentUser?.uid ? 'items-end' : 'items-start'}`}>
            <div className={`flex items-end gap-2 max-w-[85%] ${m.senderId === currentUser?.uid ? 'flex-row-reverse' : ''}`}>
              <img src={m.senderPhoto} className="w-6 h-6 rounded-full" alt="" />
              <div className={`px-4 py-2 rounded-2xl text-xs ${m.senderId === currentUser?.uid ? 'bg-blue-600 text-white rounded-br-none' : 'bg-gray-100 text-gray-800 rounded-bl-none'}`}>
                {m.text}
              </div>
            </div>
            <span className="text-[8px] font-bold text-gray-400 mt-1 uppercase px-8">{m.senderName.split(' ')[0]}</span>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t shrink-0">
        <div className="relative">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Say something..."
            className="w-full bg-gray-50 border-none rounded-2xl pl-4 pr-12 py-3 text-xs outline-none focus:ring-2 focus:ring-blue-100"
          />
          <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-blue-600 hover:scale-110 transition-transform"><Send size={16}/></button>
        </div>
      </form>
    </div>
  );
};
