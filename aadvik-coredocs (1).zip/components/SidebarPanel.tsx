
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, MessageSquare, ListTodo, History, CheckCircle2, Circle } from 'lucide-react';
import { ChatMessage, Task, Activity } from '../types';

interface SidebarPanelProps {
  tab: 'chat' | 'tasks' | 'feed' | null;
  onClose: () => void;
  messages: ChatMessage[];
  tasks: Task[];
  activities: Activity[];
  onSendChat: (text: string) => void;
  onToggleTask: (id: string, completed: boolean) => void;
  currentUser: any;
}

export const SidebarPanel: React.FC<SidebarPanelProps> = ({ tab, onClose, messages, tasks, activities, onSendChat, onToggleTask, currentUser }) => {
  const [chatInput, setChatInput] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, tab]);

  if (!tab) return null;

  return (
    <div className="w-80 h-full bg-white border-l border-gray-100 flex flex-col z-[150] animate-in slide-in-from-right-4 duration-300">
      <div className="p-6 border-b flex items-center justify-between">
        <div className="flex items-center gap-3">
          {tab === 'chat' && <MessageSquare size={18} className="text-blue-600" />}
          {tab === 'tasks' && <ListTodo size={18} className="text-blue-600" />}
          {tab === 'feed' && <History size={18} className="text-blue-600" />}
          <span className="text-[10px] font-black uppercase tracking-widest">
            {tab === 'chat' ? 'Collab Chat' : tab === 'tasks' ? 'Action Items' : 'Activity Log'}
          </span>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full"><X size={18}/></button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {tab === 'chat' && (
          <div className="p-4 space-y-4">
            {messages.map((m) => (
              <div key={m.id} className={`flex flex-col ${m.senderId === currentUser?.uid ? 'items-end' : 'items-start'}`}>
                <div className={`flex items-end gap-2 max-w-[85%] ${m.senderId === currentUser?.uid ? 'flex-row-reverse' : ''}`}>
                  <img src={m.senderPhoto} className="w-6 h-6 rounded-full" alt="" />
                  <div className={`px-4 py-2 rounded-2xl text-xs ${m.senderId === currentUser?.uid ? 'bg-blue-600 text-white rounded-br-none' : 'bg-gray-100 text-gray-800 rounded-bl-none'}`}>
                    {m.text}
                  </div>
                </div>
                <span className="text-[8px] font-bold text-gray-400 mt-1 uppercase px-8">{m.senderName.split(' ')[0]}</span>
              </div>
            ))}
            <div ref={endRef} />
          </div>
        )}

        {tab === 'tasks' && (
          <div className="p-4 space-y-3">
            {tasks.map((t) => (
              <div key={t.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all cursor-pointer group" onClick={() => onToggleTask(t.id, !t.completed)}>
                <button className="text-blue-600">
                  {t.completed ? <CheckCircle2 size={18} /> : <Circle size={18} className="opacity-30 group-hover:opacity-100" />}
                </button>
                <div className="flex-1">
                  <p className={`text-[11px] font-bold ${t.completed ? 'line-through opacity-40' : ''}`}>{t.text}</p>
                  <p className="text-[8px] opacity-40 uppercase font-black tracking-widest mt-1">By {t.createdBy}</p>
                </div>
              </div>
            ))}
            {tasks.length === 0 && <p className="text-center py-20 text-[10px] opacity-30 font-black uppercase tracking-widest">No action items found</p>}
          </div>
        )}

        {tab === 'feed' && (
          <div className="p-4 space-y-6">
            {activities.map((a) => (
              <div key={a.id} className="flex gap-4 border-l-2 border-blue-100 pl-4 py-1">
                <div className="flex-1">
                  <p className="text-xs text-gray-600">
                    <span className="font-bold text-gray-900">{a.userName}</span> {a.action}
                  </p>
                  <p className="text-[9px] font-black uppercase tracking-widest text-gray-400 mt-1">
                    {a.timestamp?.toDate().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {tab === 'chat' && (
        <form className="p-4 border-t" onSubmit={(e) => { e.preventDefault(); onSendChat(chatInput); setChatInput(''); }}>
          <div className="relative">
            <input 
              type="text" 
              value={chatInput} 
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Type message..." 
              className="w-full bg-gray-100 rounded-2xl px-4 py-3 text-xs outline-none focus:ring-2 focus:ring-blue-100" 
            />
            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-blue-600"><Send size={16}/></button>
          </div>
        </form>
      )}
    </div>
  );
};
