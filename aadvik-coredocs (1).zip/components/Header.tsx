
import React, { useRef } from 'react';
import { Share2, PenTool, MessageSquare, ListTodo, History, Mic, MicOff, Zap, Mail, Presentation, Loader2, Image as ImageIcon, SearchCheck, FileJson, Download, Columns, X } from 'lucide-react';
import { SyncStatus, UserPresence, BrandingSettings } from '../types';

interface HeaderProps {
  user: any;
  title: string;
  onTitleChange: (t: string) => void;
  syncStatus: SyncStatus;
  collaborators: UserPresence[];
  onToggleTab: (tab: 'chat' | 'tasks' | 'feed') => void;
  activeTab: 'chat' | 'tasks' | 'feed' | null;
  onExtractTasks: () => void;
  onConvertToSlides: () => void;
  isGeneratingSlides: boolean;
  isListening: boolean;
  onToggleMic: () => void;
  onSignClick: () => void;
  onEmailClick: () => void;
  onOCRClick: (file: File) => void;
  isOCRProcessing: boolean;
  onProofread: () => void;
  onExportJSON: () => void;
  isSplitView: boolean;
  toggleSplitView: () => void;
  branding: BrandingSettings;
}

export const Header: React.FC<HeaderProps> = ({ 
  user, title, onTitleChange, syncStatus, collaborators, onToggleTab, activeTab, onExtractTasks, onConvertToSlides, isGeneratingSlides, isListening, onToggleMic, onSignClick, onEmailClick,
  onOCRClick, isOCRProcessing, onProofread, onExportJSON, isSplitView, toggleSplitView, branding
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      onOCRClick(e.target.files[0]);
    }
  };

  return (
    <header className="flex flex-col bg-white border-b border-gray-100 no-print relative z-[100] shadow-sm">
      <div className="h-16 px-8 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-[12px] shadow-lg overflow-hidden border border-gray-100/10"
              style={{ backgroundColor: branding.primaryColor }}
            >
              {branding.logoUrl ? (
                <img src={branding.logoUrl} className="w-full h-full object-contain" />
              ) : (
                branding.companyName.substring(0, 2).toUpperCase()
              )}
            </div>
            <div className="flex flex-col">
              <span className="text-[11px] font-black tracking-[0.2em] text-slate-800 uppercase leading-none">{branding.companyName}</span>
              <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-1">Core Intelligence v3.0</span>
            </div>
          </div>
          
          <div className="flex items-center -space-x-2 pl-4">
            {collaborators.map(c => (
              <img key={c.uid} src={c.photo} className="w-8 h-8 rounded-full border-2 border-white shadow-sm ring-1 ring-slate-100" title={c.name} />
            ))}
          </div>
        </div>

        <div className="flex-1 max-w-md px-12 text-center">
          <input 
            type="text" 
            value={title} 
            onChange={(e) => onTitleChange(e.target.value)} 
            className="text-[13px] font-black bg-transparent px-6 py-3 rounded-2xl hover:bg-black/5 outline-none w-full text-center transition-all focus:bg-gray-50 focus:ring-2 focus:ring-blue-100" 
            placeholder="Name your strategic artifact..."
          />
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={toggleSplitView} 
            className={`p-3 rounded-2xl transition-all border ${isSplitView ? 'bg-slate-900 text-white border-slate-900 shadow-xl' : 'text-slate-400 border-transparent hover:bg-gray-100'}`}
            title="Split Workspace"
          >
            <Columns size={20}/>
          </button>

          <button 
            onClick={onToggleMic} 
            className={`p-3 rounded-2xl transition-all border ${isListening ? 'bg-red-50 text-red-600 border-red-100 animate-pulse shadow-lg' : 'text-slate-400 border-transparent hover:bg-gray-100'}`}
          >
            {isListening ? <Mic size={20}/> : <MicOff size={20}/>}
          </button>

          <div className="flex items-center bg-gray-50 p-1.5 rounded-[22px] border border-gray-100">
            <TabButton active={activeTab === 'chat'} onClick={() => onToggleTab('chat')} icon={MessageSquare} />
            <TabButton active={activeTab === 'tasks'} onClick={() => onToggleTab('tasks')} icon={ListTodo} />
            <TabButton active={activeTab === 'feed'} onClick={() => onToggleTab('feed')} icon={History} />
          </div>

          <div className="w-[1px] h-8 bg-gray-200" />
          
          {user && (
            <div className="relative group cursor-pointer">
              <img src={user.photoURL} className="w-10 h-10 rounded-full border-2 border-white shadow-xl ring-1 ring-blue-100" alt="Profile" />
              <div className="absolute top-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
            </div>
          )}
        </div>
      </div>
      
      <div className="h-14 px-8 flex items-center gap-6 bg-[#FDFDFD]">
         <div className="flex items-center gap-3">
           <button onClick={onExtractTasks} className="flex items-center gap-3 px-6 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:opacity-95 transition-all active:scale-95">
             <Zap size={16} className="text-blue-400"/> Synthesize Action Items
           </button>
           <button 
             onClick={onConvertToSlides} 
             disabled={isGeneratingSlides}
             className="flex items-center gap-3 px-6 py-2.5 bg-[var(--primary)] text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:opacity-95 transition-all active:scale-95 disabled:opacity-50"
           >
             {isGeneratingSlides ? <Loader2 size={16} className="animate-spin"/> : <Presentation size={16}/>} Generate Deck
           </button>
         </div>
         
         <div className="w-[1px] h-6 bg-gray-200"/>

         <div className="flex items-center gap-2">
           <ToolbarAction 
             onClick={() => fileInputRef.current?.click()} 
             disabled={isOCRProcessing}
             icon={ImageIcon} 
             label="Neural OCR" 
             loading={isOCRProcessing}
           />
           <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />

           <ToolbarAction onClick={onProofread} icon={SearchCheck} label="Deep Proofread" />
           <ToolbarAction onClick={onEmailClick} icon={Mail} label="Cloud Dispatch" />
           <ToolbarAction onClick={onSignClick} icon={PenTool} label="Execute Sign" />
         </div>
         
         <div className="ml-auto flex items-center gap-4">
           <div className="relative group">
              <button className="flex items-center gap-3 px-6 py-2.5 bg-white border border-gray-100 text-slate-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-50 transition-all shadow-sm">
                <Download size={16} className="text-slate-400" /> Export Artifact
              </button>
              <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-100 rounded-2xl shadow-[0_20px_80px_rgba(0,0,0,0.1)] opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-all translate-y-3 group-hover:translate-y-0 z-[200] overflow-hidden p-2">
                <ExportOption onClick={() => window.print()} icon={Download} label="Professional PDF" sub="Vector optimized A4" />
                <ExportOption onClick={onExportJSON} icon={FileJson} label="Aadvik JSON" sub="Strategic data map" />
              </div>
           </div>
           
           <button onClick={() => window.print()} className="bg-[var(--primary)] text-white px-8 py-3 rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-2xl flex items-center gap-3 hover:opacity-90 transition-all active:scale-95">
             <Share2 size={16} /> Distribute
           </button>
         </div>
      </div>
    </header>
  );
};

const TabButton = ({ active, onClick, icon: Icon }: any) => (
  <button onClick={onClick} className={`p-2.5 rounded-[18px] transition-all ${active ? 'bg-white text-blue-600 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}>
    <Icon size={18} />
  </button>
);

const ToolbarAction = ({ onClick, icon: Icon, label, disabled, loading }: any) => (
  <button 
    onClick={onClick} 
    disabled={disabled}
    className="flex items-center gap-2 px-4 py-2 hover:bg-white rounded-xl transition-all text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 border border-transparent hover:border-gray-100 disabled:opacity-50"
  >
    {loading ? <Loader2 size={14} className="animate-spin" /> : <Icon size={14} className="text-slate-300 group-hover:text-blue-500" />}
    <span>{label}</span>
  </button>
);

const ExportOption = ({ onClick, icon: Icon, label, sub }: any) => (
  <button onClick={onClick} className="w-full text-left p-4 rounded-xl flex items-center gap-4 hover:bg-blue-50 transition-all group">
    <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-white group-hover:text-blue-600 shadow-sm transition-all"><Icon size={18} /></div>
    <div>
      <p className="text-[10px] font-black uppercase tracking-widest text-slate-700 group-hover:text-blue-600">{label}</p>
      <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{sub}</p>
    </div>
  </button>
);
