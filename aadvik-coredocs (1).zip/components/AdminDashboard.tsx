
import React from 'react';
import { X, Activity, Terminal, Palette, BarChart, Zap, Mic, ShieldCheck, Trash2 } from 'lucide-react';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  stats: {
    aiImageClicks: number;
    micClicks: number;
  };
  logs: string[];
  onClearLogs: () => void;
  primaryColor: string;
  onColorChange: (color: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  isOpen, onClose, stats, logs, onClearLogs, primaryColor, onColorChange 
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[2000] flex">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={onClose} />
      
      {/* Dashboard Panel */}
      <div className="relative w-[450px] bg-[#0f1113] border-r border-white/10 h-full flex flex-col shadow-2xl animate-in slide-in-from-left duration-500">
        <div className="p-8 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center text-white shadow-[0_0_20px_rgba(220,38,38,0.4)]">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h2 className="text-xs font-black uppercase tracking-[0.3em] text-white">Super-Admin</h2>
              <p className="text-[9px] text-red-500 font-bold uppercase tracking-widest mt-0.5">Core Diagnostics Active</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-white/40 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-10 no-scrollbar">
          {/* Section: Session Monitoring */}
          <div className="space-y-6">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 flex items-center gap-2">
              <Activity size={14} /> Session Monitor
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <StatCard icon={Zap} label="AI Generations" value={stats.aiImageClicks} color="text-yellow-400" />
              <StatCard icon={Mic} label="Mic Activations" value={stats.micClicks} color="text-blue-400" />
            </div>
          </div>

          {/* Section: Theme Customizer */}
          <div className="space-y-6">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 flex items-center gap-2">
              <Palette size={14} /> Live Customizer
            </h3>
            <div className="bg-white/5 p-6 rounded-[24px] border border-white/5">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] font-bold text-white/80">Primary Accent</span>
                <span className="text-[10px] font-mono text-white/40 uppercase">{primaryColor}</span>
              </div>
              <input 
                type="color" 
                value={primaryColor} 
                onChange={(e) => onColorChange(e.target.value)}
                className="w-full h-12 bg-transparent cursor-pointer rounded-xl overflow-hidden"
              />
              <p className="text-[9px] text-white/30 mt-4 italic">Changes reflect globally across all CSS variables.</p>
            </div>
          </div>

          {/* Section: Console Logs */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 flex items-center gap-2">
                <Terminal size={14} /> System Console
              </h3>
              <button onClick={onClearLogs} className="text-[8px] font-black uppercase tracking-widest text-red-500 hover:opacity-80 transition-opacity">
                Clear Buffer
              </button>
            </div>
            <div className="bg-black/40 rounded-[24px] border border-white/5 p-6 font-mono text-[10px] h-[250px] overflow-y-auto no-scrollbar space-y-2">
              {logs.length === 0 ? (
                <p className="text-white/20 italic">No errors captured in current session...</p>
              ) : (
                logs.map((log, i) => (
                  <div key={i} className="flex gap-3">
                    <span className="text-red-500/50">[{i+1}]</span>
                    <span className="text-red-400 break-all">{log}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="p-8 border-t border-white/10 bg-white/[0.02]">
          <p className="text-[8px] font-black uppercase tracking-widest text-white/20 text-center">
            Aadvik Intelligence Systems v2.4.0-Stable
          </p>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon: Icon, label, value, color }: any) => (
  <div className="bg-white/5 p-5 rounded-[24px] border border-white/5 flex flex-col gap-3">
    <div className={`${color} opacity-80`}><Icon size={18}/></div>
    <div>
      <div className="text-2xl font-black text-white">{value}</div>
      <div className="text-[9px] font-black uppercase tracking-widest text-white/30">{label}</div>
    </div>
  </div>
);
