
/**
 * Aadvik CoreDocs - Cloud Sync Service
 * Optimized for Replit environment using standard JSON API patterns.
 */

export interface CloudDoc {
  id: string;
  title: string;
  content: string;
  updatedAt: number;
}

// Function to save data to the cloud (e.g., a Replit backend)
export async function saveToCloud(userId: string, docId: string, data: Partial<CloudDoc>): Promise<void> {
  // In a real Replit deployment, you'd create an express route to handle this
  // and store it in Replit KV. For now, we simulate the network delay.
  try {
    const response = await fetch('/api/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, docId, ...data }),
    });
    
    // If running purely client-side without a backend yet, fallback to a labeled "Cloud Mock"
    if (!response.ok) {
      localStorage.setItem(`aadvik_cloud_${userId}_${docId}`, JSON.stringify({
        ...data,
        updatedAt: Date.now()
      }));
    }
  } catch (error) {
    // Fallback logic if the backend doesn't exist yet
    localStorage.setItem(`aadvik_cloud_${userId}_${docId}`, JSON.stringify({
      ...data,
      updatedAt: Date.now()
    }));
    await new Promise(resolve => setTimeout(resolve, 800)); // Simulate latency
  }
}

// Function to load the last saved document from the cloud
export async function loadFromCloud(userId: string, docId: string): Promise<CloudDoc | null> {
  try {
    const response = await fetch(`/api/load?userId=${userId}&docId=${docId}`);
    if (response.ok) {
      return await response.json();
    }
    
    // Mock/Fallback
    const saved = localStorage.getItem(`aadvik_cloud_${userId}_${docId}`);
    return saved ? JSON.parse(saved) : null;
  } catch (error) {
    const saved = localStorage.getItem(`aadvik_cloud_${userId}_${docId}`);
    return saved ? JSON.parse(saved) : null;
  }
}

// Simple Mock Auth for Replit Preview (Replacing Firebase Auth)
export const mockLogin = () => {
  const user = {
    uid: 'replit-user-123',
    displayName: 'Aadvik User',
    photoURL: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aadvik'
  };
  localStorage.setItem('aadvik_user', JSON.stringify(user));
  return user;
};

export const getStoredUser = () => {
  const user = localStorage.getItem('aadvik_user');
  return user ? JSON.parse(user) : null;
};
