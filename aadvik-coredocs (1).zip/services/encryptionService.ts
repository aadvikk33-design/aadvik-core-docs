
import CryptoJS from 'https://esm.sh/crypto-js@4.2.0';

export const encryptContent = (content: string, masterKey: string): string => {
  return CryptoJS.AES.encrypt(content, masterKey).toString();
};

export const decryptContent = (encryptedContent: string, masterKey: string): string => {
  try {
    const bytes = CryptoJS.AES.decrypt(encryptedContent, masterKey);
    return bytes.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error("Decryption failed: Invalid Master Key");
    return "";
  }
};
