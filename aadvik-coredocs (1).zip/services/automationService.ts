
// automationService.ts
// Optimized for the mc_microsoft_core service ID

export async function sendDocumentEmail(params: {
  to_email: string;
  to_name: string;
  doc_title: string;
  sender_name: string;
  pdf_base64: string;
}) {
  try {
    // Service ID provided by user: mc_microsoft_core
    // Note: Template ID 'template_aadvik_doc' is a placeholder; ensure it matches your EmailJS dashboard
    const response = await (window as any).emailjs.send(
      "mc_microsoft_core",
      "template_aadvik_doc", 
      {
        to_name: params.to_name,
        to_email: params.to_email,
        from_name: params.sender_name,
        doc_title: params.doc_title,
        attachment: params.pdf_base64, // The base64 string of the PDF
        room_link: window.location.href
      }
    );
    return response;
  } catch (error) {
    console.error("Critical Automation Error:", error);
    throw error;
  }
}

export async function sendTaskAlert(params: {
  to_email: string;
  task_text: string;
  assigner: string;
}) {
  try {
    const response = await (window as any).emailjs.send(
      "mc_microsoft_core",
      "template_task_alert",
      params
    );
    return response;
  } catch (error) {
    console.error("Task Alert Notification Failure:", error);
  }
}
