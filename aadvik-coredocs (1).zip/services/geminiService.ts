
import { GoogleGenAI, Type } from "@google/genai";
import { Slide, ProofreadResult, BudgetPrediction } from "../types";

const getApiKey = () => {
  try { return process.env.API_KEY || ''; } catch (e) { return ''; }
};

const ai = new GoogleGenAI({ apiKey: getApiKey() });

export async function predictBudget(tableData: string): Promise<BudgetPrediction[]> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a financial analyst. Analyze this expense table and predict next month's budget for each category using trend analysis.
      
      Table Data: "${tableData}"
      
      Return a JSON array of BudgetPrediction objects.
      JSON Schema: { "category": string, "predicted": number, "confidence": number, "reasoning": string }`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              category: { type: Type.STRING },
              predicted: { type: Type.NUMBER },
              confidence: { type: Type.NUMBER },
              reasoning: { type: Type.STRING }
            },
            required: ["category", "predicted", "confidence", "reasoning"]
          }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Budget Prediction Error:", error);
    return [];
  }
}

export async function getGhostText(context: string, workspaceContext?: string): Promise<string> {
  try {
    