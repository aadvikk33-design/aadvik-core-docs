
import React, { useState } from 'react';
import { Bold, Italic, Underline, List, AlignLeft, AlignCenter, AlignRight, Share2, Sparkles, Download, Maximize2, Cpu, FileJson } from 'lucide-react';
import { enhanceText } from '../services/geminiService';

interface HeaderProps {
  title: string;
  onTitleChange: (title: string) => void;
  content: string;
  onUpdateContent: (content: string) => void;
  isFocusMode: boolean;
  toggleFocus: () => void;
  onExportJSON: () => void;
}

export const Header: React.FC<HeaderProps> = ({ title, onTitleChange, content, onUpdateContent, isFocusMode, toggleFocus, onExportJSON }) => {
  const [isAIProcessing, setIsAIProcessing] = useState(false);

  const formatDoc = (cmd: string, value?: string) => {
    document.execCommand(cmd, false, value);
  };

  const handleAIEnhance = async () => {
    setIsAIProcessing(true);
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = content;
    const plainText = tempDiv.innerText;
    const improved = await enhanceText(plainText);
    onUpdateContent(`<p>${improved.replace(/\n/g, '</p><p>')}</p>`);
    setIsAIProcessing(false);
  };

  return (
    <header className="h-24 bg-[var(--glass-bg)] glass-effect border-b border-[var(--border-color)] flex flex-col z-30 sticky top-0 shrink-0 shadow-sm no-print">
      <div className="flex-1 flex items-center px-8 justify-between">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 group cursor-pointer">
            <div className="w-5 h-5 bg-[#0078D4] rounded-sm flex items-center justify-center text-white font-black text-[8px]">AD</div>
            <span className="text-[10px] font-black tracking-[0.2em] text-[#0078D4] uppercase">Aadvik CoreDocs</span>
          </div>
          <div className="w-[1px] h-6 bg-[var(--border-color)]" />
          <input 
            type="text" 
            value={title} 
            onChange={(e) => onTitleChange(e.target.value)}
            className="text-sm font-bold text-[var(--text-main)] bg-transparent hover:bg-black/5 dark:hover:bg-white/5 px-4 py-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0078D4]/30 transition-all w-80"
          />
        </div>

        <div className="flex items-center gap-4">
          <button onClick={toggleFocus} className="p-2.5 text-gray-400 hover:text-[#0078D4] hover:bg-blue-500/5 rounded-xl transition-all"><Maximize2 size={18} /></button>
          
          <div className="relative group">
            <button className="flex items-center gap-2 text-gray-500 hover:text-[var(--text-main)] px-4 py-2 text-xs font-bold uppercase tracking-widest border border-[var(--border-color)] rounded-xl transition-all">
              <Download size={14} />
              <span>Export</span>
            </button>
            <div className="absolute right-0 top-full mt-2 w-52 bg-[var(--bg-page)] border border-[var(--border-color)] rounded-xl shadow-2xl opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-all translate-y-2 group-hover:translate-y-0 z-50 overflow-hidden">
              <ExportItem icon={Download} label="PDF Output" onClick={() => window.print()} />
              <ExportItem icon={FileJson} label="Aadvik JSON" onClick={onExportJSON} />
            </div>
          </div>

          <button className="flex items-center gap-2 bg-[#0078D4] hover:bg-[#005A9E] text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg active:scale-95 transition-all">
            <Share2 size={14} />
            <span>Publish</span>
          </button>
        </div>
      </div>

      <div className="h-10 px-8 flex items-center gap-1.5 overflow-x-auto no-scrollbar border-t border-[var(--border-color)]/30">
        <select onChange={(e) => formatDoc('fontName', e.target.value)} className="text-[10px] font-black uppercase tracking-widest bg-transparent border-none outline-none text-gray-400 mr-4 cursor-pointer hover:text-[#0078D4]">
          <option value="Inter">Standard</option>
          <option value="Georgia">Editorial</option>
          <option value="Courier New">Monospace</option>
        </select>
        <ToolbarButton icon={Bold} onClick={() => formatDoc('bold')} />
        <ToolbarButton icon={Italic} onClick={() => formatDoc('italic')} />
        <ToolbarButton icon={Underline} onClick={() => formatDoc('underline')} />
        <div className="h-4 w-[1px] bg-[var(--border-color)] mx-2" />
        <ToolbarButton icon={AlignLeft} onClick={() => formatDoc('justifyLeft')} />
        <ToolbarButton icon={AlignCenter} onClick={() => formatDoc('justifyCenter')} />
        <ToolbarButton icon={AlignRight} onClick={() => formatDoc('justifyRight')} />
        <div className="h-4 w-[1px] bg-[var(--border-color)] mx-2" />
        <button onClick={handleAIEnhance} disabled={isAIProcessing} className={`flex items-center gap-2 px-4 py-1.5 rounded-lg transition-all ${isAIProcessing ? 'bg-gray-200 text-gray-400' : 'text-indigo-500 bg-indigo-500/5 hover:bg-indigo-500/10 active:scale-95'}`}>
          <Sparkles size={14} className={isAIProcessing ? 'animate-spin' : ''} />
          <span className="text-[9px] font-black uppercase tracking-[0.2em]">AI Rewrite</span>
        </button>
      </div>
    </header>
  );
};

const ToolbarButton: React.FC<{ icon: any; onClick: () => void }> = ({ icon: Icon, onClick }) => (
  <button onClick={onClick} className="p-1.5 text-gray-400 hover:text-[#0078D4] hover:bg-blue-500/5 rounded-lg transition-all">
    <Icon size={16} strokeWidth={2.5} />
  </button>
);

const ExportItem: React.FC<{ icon: any; label: string; onClick: () => void }> = ({ icon: Icon, label, onClick }) => (
  <button onClick={onClick} className="w-full text-left px-4 py-3 flex items-center gap-3 text-[10px] font-bold uppercase tracking-wider hover:bg-blue-500 hover:text-white transition-colors">
    <Icon size={14} />
    <span>{label}</span>
  </button>
);
