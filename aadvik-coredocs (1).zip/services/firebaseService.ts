
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore, doc, setDoc, collection, query, onSnapshot, deleteDoc, Timestamp, orderBy, limit, addDoc, serverTimestamp, updateDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAs-Placeholder-Key",
  authDomain: "aadvik-coredocs.firebaseapp.com",
  projectId: "aadvik-coredocs",
  storageBucket: "aadvik-coredocs.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = () => signInWithPopup(auth, googleProvider);
export const logoutUser = () => signOut(auth);

export { onAuthStateChanged };

export const subscribeToDoc = (docId: string, callback: (data: any) => void) => {
  return onSnapshot(doc(db, "documents", docId), (snapshot) => {
    if (snapshot.exists()) callback(snapshot.data());
  });
};

export const updateDocContent = async (docId: string, data: any) => {
  await setDoc(doc(db, "documents", docId), { ...data, updatedAt: serverTimestamp() }, { merge: true });
};

export const updatePresence = async (docId: string, userId: string, data: any) => {
  const presenceRef = doc(db, "documents", docId, "presence", userId);
  await setDoc(presenceRef, { ...data, lastSeen: serverTimestamp() }, { merge: true });
};

export const subscribeToPresence = (docId: string, callback: (users: any[]) => void) => {
  const q = query(collection(db, "documents", docId, "presence"));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => doc.data()));
  });
};

// Task Sync
export const addTask = async (docId: string, task: any) => {
  const taskRef = collection(db, "documents", docId, "tasks");
  await addDoc(taskRef, { ...task, createdAt: serverTimestamp() });
};

export const updateTaskStatus = async (docId: string, taskId: string, completed: boolean) => {
  const taskRef = doc(db, "documents", docId, "tasks", taskId);
  await updateDoc(taskRef, { completed });
};

export const subscribeToTasks = (docId: string, callback: (tasks: any[]) => void) => {
  const q = query(collection(db, "documents", docId, "tasks"), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  });
};

// Activity Log
export const logActivity = async (docId: string, activity: any) => {
  const logRef = collection(db, "documents", docId, "activities");
  await addDoc(logRef, { ...activity, timestamp: serverTimestamp() });
};

export const subscribeToActivities = (docId: string, callback: (acts: any[]) => void) => {
  const q = query(collection(db, "documents", docId, "activities"), orderBy("timestamp", "desc"), limit(15));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  });
};

// Chat
export const sendChatMessage = async (docId: string, message: any) => {
  const chatRef = collection(db, "documents", docId, "messages");
  await addDoc(chatRef, { ...message, timestamp: serverTimestamp() });
};

export const subscribeToChat = (docId: string, callback: (msgs: any[]) => void) => {
  const q = query(collection(db, "documents", docId, "messages"), orderBy("timestamp", "asc"), limit(50));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  });
};
