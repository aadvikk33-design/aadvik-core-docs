
import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Canvas } from './components/Canvas';
import { SidebarPanel } from './components/SidebarPanel';
import { Sidebar } from './components/Sidebar';
import { SignaturePad } from './components/SignaturePad';
import { PresentationOverlay } from './components/PresentationOverlay';
import { AdminDashboard } from './components/AdminDashboard';
import { AppSettings, SyncStatus, UserPresence, ChatMessage, Task, Activity, Toast, Slide, SidebarTab, ProofreadResult } from './types';
import { auth, loginWithGoogle, logoutUser, updateDocContent, subscribeToDoc, updatePresence, subscribeToPresence, sendChatMessage, subscribeToChat, addTask, updateTaskStatus, subscribeToTasks, logActivity, subscribeToActivities, onAuthStateChanged } from './services/firebaseService';
import { extractTasks, generateSlidesFromContent, analyzeSentiment, proofreadDocument, conductResearch } from './services/geminiService';
import { Mic, Zap, ListTodo, History, Mail, X, CheckCircle2, AlertCircle, Info, Loader2, EyeOff, SearchCheck, Globe, Lock, ShieldCheck, Columns, Languages, Palette, Upload } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('synced');
  const [docId, setDocId] = useState<string | null>(null);
  const [docData, setDocData] = useState<any>(null);
  const [collaborators, setCollaborators] = useState<UserPresence[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  
  // Enterprise UI States
  const [activeSidebarTab, setActiveSidebarTab] = useState<SidebarTab>(SidebarTab.HOME);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [rightSidebarTab, setRightSidebarTab] = useState<'chat' | 'tasks' | 'feed' | null>(null);
  const [showSignature, setShowSignature] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [slides, setSlides] = useState<Slide[] | null>(null);
  const [isGeneratingSlides, setIsGeneratingSlides] = useState(false);
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [sentiment, setSentiment] = useState({ tone: 'Neutral', score: 50 });
  
  // Advanced Strategic States
  const [isLocked, setIsLocked] = useState(false);
  const [docPin, setDocPin] = useState<string | null>(null);
  const [isSplitView, setIsSplitView] = useState(false);
  const [isResearchOpen, setIsResearchOpen] = useState(false);
  const [researchQuery, setResearchQuery] = useState('');
  const [researchResult, setResearchResult] = useState<{ answer: string, sources: any[] } | null>(null);
  const [isResearching, setIsResearching] = useState(false);
  const [workspaceMemory, setWorkspaceMemory] = useState<string>('');

  const [settings, setSettings] = useState<AppSettings>({ 
    fontFamily: "'Inter', sans-serif", pageSize: 'A4', primaryColor: 'blue',
    showWordCount: true, enableAIImage: true, watermark: 'none', darkMode: false,
    branding: { primaryColor: '#0078D4', secondaryColor: '#F8F9FA', companyName: 'Aadvik Enterprises', logoUrl: '' }
  });

  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const sentimentTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Workspace Memory Integration
  useEffect(() => {
    if (user) {
      const themes = ["Project Phoenix logistics", "Q3 Strategic QBR", "Enterprise Cloud Migration"];
      setWorkspaceMemory(themes.join(', '));
    }
  }, [user]);

  // Branding Synchronization via CSS variables
  useEffect(() => {
    document.documentElement.style.setProperty('--primary', settings.branding.primaryColor);
    document.documentElement.style.setProperty('--primary-main', settings.branding.primaryColor);
    document.documentElement.style.setProperty('--brand-secondary', settings.branding.secondaryColor);
  }, [settings.branding]);

  // Context-Aware Mood Adaptation
  useEffect(() => {
    if (sentiment.tone === 'Poetic' || sentiment.tone === 'Creative') {
      setSettings(s => ({ ...s, darkMode: true }));
    } else if (sentiment.tone === 'Professional' || sentiment.tone === 'Academic') {
      setSettings(s => ({ ...s, darkMode: false }));
    }
  }, [sentiment.tone]);

  useEffect(() => {
    const runSentiment = async () => {
      const page = document.querySelector('.a4-page');
      const text = page?.textContent || '';
      if (text.length > 50) {
        try {
          const result = await analyzeSentiment(text);
          setSentiment(result);
        } catch (e) {}
      }
      sentimentTimeoutRef.current = setTimeout(runSentiment, 15000);
    };

    if (docData?.content) {
      if (sentimentTimeoutRef.current) clearTimeout(sentimentTimeoutRef.current);
      sentimentTimeoutRef.current = setTimeout(runSentiment, 5000);
    }
    return () => { if (sentimentTimeoutRef.current) clearTimeout(sentimentTimeoutRef.current); };
  }, [docId, !!docData?.content]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    let id = params.get('id');
    if (!id) {
      id = 'doc_' + Math.random().toString(36).substr(2, 9);
      window.history.replaceState(null, '', `?id=${id}`);
    }
    setDocId(id);
  }, []);

  useEffect(() => {
    if (!docId) return;
    const unsubAuth = onAuthStateChanged(auth, (u) => { setUser(u); setIsLoading(false); });
    const unsubDoc = subscribeToDoc(docId, (data) => {
      setDocData(data);
      if (data.pin && !isLocked && !docPin) {
         setIsLocked(true);
         setDocPin(data.pin);
      }
    });
    const unsubPresence = subscribeToPresence(docId, (users) => setCollaborators(users));
    const unsubChat = subscribeToChat(docId, (msgs) => setMessages(msgs));
    const unsubTasks = subscribeToTasks(docId, (ts) => setTasks(ts));
    const unsubActs = subscribeToActivities(docId, (acts) => setActivities(acts));
    return () => { unsubAuth(); unsubDoc(); unsubPresence(); unsubChat(); unsubTasks(); unsubActs(); };
  }, [docId]);

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'info', action?: () => void, actionLabel?: string) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, message, type, action, actionLabel }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 8000);
  };

  const handleTranslationOffer = (translated: string) => {
    addToast(
      "AI detected foreign language in your paste.", 
      "info", 
      () => {
        document.execCommand('insertHTML', false, translated);
      },
      "Paste as Translated English"
    );
  };

  const handleResearch = async () => {
    if (!researchQuery.trim()) return;
    setIsResearching(true);
    addToast("Initializing Global Web Grounding...", "info");
    const result = await conductResearch(researchQuery);
    setResearchResult(result);
    setIsResearching(false);
  };

  const insertResearch = () => {
    if (!researchResult) return;
    const sourcesHtml = researchResult.sources.map(s => `<li><a href="${s.uri}" target="_blank" style="color:var(--primary)">${s.title}</a></li>`).join('');
    const content = `<div class="p-6 bg-slate-50 border-l-4 border-blue-500 my-8 rounded-r-2xl"><h3>AI Research: ${researchQuery}</h3><p>${researchResult.answer}</p><h4>Sources:</h4><ul>${sourcesHtml}</ul></div>`;
    document.execCommand('insertHTML', false, content);
    setIsResearchOpen(false);
  };

  const handleUnlock = (pin: string) => {
    if (pin === docPin) {
       setIsLocked(false);
       addToast("Vault Decrypted", "success");
    } else {
       addToast("Access Denied: Invalid Key", "error");
    }
  };

  const handleUpdateContent = (content: string) => {
    if (!docId) return;
    setSyncStatus('syncing');
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(async () => {
      await updateDocContent(docId, { content });
      setSyncStatus('synced');
    }, 1500);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSettings(s => ({
          ...s,
          branding: { ...s.branding, logoUrl: reader.result as string }
        }));
        addToast("Corporate Branding Updated", "success");
      };
      reader.readAsDataURL(file);
    }
  };

  if (isLoading) return <LoadingScreen />;

  return (
    <div className={`flex h-screen w-screen bg-[#F8F9FA] text-[#1A1C1E] overflow-hidden ${isFocusMode ? 'focus-mode' : ''} ${settings.darkMode ? 'dark-theme' : ''}`}>
      
      {!isFocusMode && !isLocked && (
        <Sidebar 
          user={user}
          activeTab={activeSidebarTab}
          onTabChange={setActiveSidebarTab}
          isCollapsed={isSidebarCollapsed}
          toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          isDarkMode={settings.darkMode}
          toggleDarkMode={() => setSettings({...settings, darkMode: !settings.darkMode})}
          sessions={[]}
          activeSessionId={docId || ''}
          onSwitchSession={() => {}}
          onNewSession={() => window.location.href = '/'}
          onCloseSession={() => {}}
          onLogin={loginWithGoogle}
          onLogout={logoutUser}
          onApplyTemplate={() => {}}
          onInsertImage={() => {}}
          toc={[]}
          tone={sentiment}
          credits={5}
          onOpenPricing={() => {}}
          settings={settings}
          updateSettings={(s) => setSettings({...settings, ...s})}
        />
      )}

      <div className="flex flex-col flex-1 overflow-hidden transition-all duration-700">
        {!isFocusMode && !isLocked && (
          <Header 
            user={user}
            title={docData?.title || 'Draft Workspace'}
            onTitleChange={(t) => docId && updateDocContent(docId, { title: t })}
            syncStatus={syncStatus}
            collaborators={collaborators}
            onToggleTab={(tab) => setRightSidebarTab(rightSidebarTab === tab ? null : tab)}
            onExtractTasks={async () => {
               addToast("Agent extracting strategic deliverables...", "info");
               const tempDiv = document.createElement('div');
               tempDiv.innerHTML = docData.content;
               const extracted = await extractTasks(tempDiv.innerText);
               for (const t of extracted) await addTask(docId!, { text: t.text, completed: false, createdBy: 'Aadvik Agent' });
               addToast(`Synthesized ${extracted.length} tasks`, "success");
               setRightSidebarTab('tasks');
            }}
            onConvertToSlides={async () => {
              if (!docData?.content) return;
              setIsGeneratingSlides(true);
              const tempDiv = document.createElement('div');
              tempDiv.innerHTML = docData.content;
              const generated = await generateSlidesFromContent(tempDiv.innerText);
              setSlides(generated);
              setIsGeneratingSlides(false);
            }}
            isGeneratingSlides={isGeneratingSlides}
            activeTab={rightSidebarTab}
            isListening={isListening}
            onToggleMic={() => setIsListening(!isListening)}
            onSignClick={() => setShowSignature(true)}
            onEmailClick={() => setIsEmailModalOpen(true)}
            onOCRClick={async (file) => {
               const tesseract = (window as any).Tesseract;
               if (!tesseract) {
                 addToast("OCR Engine failed to initialize.", "error");
                 return;
               }
               addToast("Neural Vision Intercept Active", "info");
               const { data: { text } } = await tesseract.recognize(file, 'eng');
               document.execCommand('insertHTML', false, `<p>${text.replace(/\n/g, '<br/>')}</p>`);
               addToast("Artifact Deciphered", "success");
            }}
            isOCRProcessing={false}
            onProofread={async () => {
              const text = document.querySelector('.a4-page')?.textContent || '';
              const result = await proofreadDocument(text);
              addToast(`Diagnostic Scan Result: ${result.score}% Accuracy`, "success");
            }}
            onExportJSON={() => {}}
            isSplitView={isSplitView}
            toggleSplitView={() => setIsSplitView(!isSplitView)}
            branding={settings.branding}
          />
        )}

        <div className="flex flex-1 overflow-hidden relative">
          <main className={`flex-1 overflow-hidden flex relative ${isSplitView ? 'flex-row' : 'flex-col'}`}>
            <div className={`canvas-container no-scrollbar transition-all duration-700 ${isFocusMode ? 'py-0 flex items-center justify-center bg-[#121212]' : ''} ${isSplitView ? 'flex-[0.6] min-w-0 border-r border-gray-100' : 'w-full'}`}>
              <Canvas 
                content={docData?.content || ''} 
                onChange={handleUpdateContent} 
                settings={settings} 
                collaborators={collaborators}
                userId={user?.uid}
                onCursorMove={(pos) => user && docId && updatePresence(docId, user.uid, { cursorPos: pos })}
                isLocked={isLocked}
                onUnlock={handleUnlock}
                onTranslationOffer={handleTranslationOffer}
                workspaceMemory={workspaceMemory}
              />
            </div>
            
            {isSplitView && (
              <div className="flex-[0.4] bg-[#FDFDFD] flex flex-col animate-in slide-in-from-right duration-500 shadow-inner">
                <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white">
                   <div className="flex items-center gap-3">
                      <Zap size={18} className="text-[var(--primary)]" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Workspace Assistant</span>
                   </div>
                   <button onClick={() => setIsSplitView(false)} className="p-2 hover:bg-gray-50 rounded-full transition-colors"><X size={18}/></button>
                </div>
                <div className="flex-1 overflow-y-auto p-10 space-y-10 no-scrollbar">
                   <div className="p-8 bg-slate-900 text-white rounded-[40px] shadow-2xl relative overflow-hidden group">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 blur-[60px] pointer-events-none group-hover:bg-blue-500/40 transition-all duration-700" />
                      <div className="flex items-center gap-4 mb-6">
                         <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-blue-500/20"><Globe size={20}/></div>
                         <h4 className="text-[12px] font-black uppercase tracking-widest tracking-[0.2em]">Strategic Research</h4>
                      </div>
                      <div className="space-y-4">
                        <input 
                          type="text" 
                          placeholder="Search live grounding..." 
                          className="w-full bg-white/10 p-5 rounded-2xl text-xs border border-white/5 outline-none focus:ring-2 focus:ring-blue-500 transition-all" 
                          onKeyDown={e => e.key === 'Enter' && handleResearch()}
                          onChange={e => setResearchQuery(e.currentTarget.value)}
                        />
                        <button onClick={handleResearch} className="w-full py-5 bg-blue-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/20 active:scale-95">
                          {isResearching ? <Loader2 className="animate-spin mx-auto"/> : 'Deploy Web Probe'}
                        </button>
                      </div>
                   </div>
                   
                   {researchResult && (
                      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
                         <div className="p-8 bg-white border border-gray-100 rounded-[32px] shadow-sm">
                            <p className="text-[14px] leading-relaxed text-slate-700 font-medium">{researchResult.answer}</p>
                         </div>
                         <div className="grid grid-cols-1 gap-4">
                            {researchResult.sources.map((s, i) => (
                               <a key={i} href={s.uri} target="_blank" className="p-4 bg-gray-50 rounded-2xl flex items-center gap-4 hover:bg-blue-50 transition-all group">
                                  <div className="w-8 h-8 bg-white rounded-xl flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform"><Globe size={14} /></div>
                                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 group-hover:text-blue-600 truncate">{s.title}</span>
                               </a>
                            ))}
                         </div>
                         <button onClick={insertResearch} className="w-full py-5 bg-slate-100 text-slate-900 rounded-[24px] text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all border border-gray-200 shadow-sm">Drag Result into Manuscript</button>
                      </div>
                   )}
                </div>
              </div>
            )}
            
            {/* Quick Actions Global Overlay */}
            {!isLocked && !isFocusMode && !isSplitView && (
              <div className="fixed bottom-12 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-white/20 backdrop-blur-2xl border border-white/40 p-3 rounded-[28px] shadow-2xl z-50 animate-in slide-in-from-bottom-10 duration-700">
                <button onClick={() => setIsSplitView(true)} className="flex items-center gap-3 px-8 py-4 bg-slate-900 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-black transition-all shadow-xl active:scale-95 group">
                  <Columns size={18} className="group-hover:rotate-90 transition-transform duration-500" /> Split Workspace
                </button>
                <button onClick={() => {
                  const p = prompt("Enter 4-Digit Identity Key to Vault:");
                  if (p && p.length === 4) {
                    updateDocContent(docId!, { pin: p });
                    setIsLocked(true);
                    setDocPin(p);
                    addToast("Workspace Vaulted", "success");
                  }
                }} className="p-4 bg-white text-slate-900 rounded-2xl hover:bg-gray-50 transition-all shadow-xl active:scale-90 border border-gray-100">
                  <ShieldCheck size={20} />
                </button>
              </div>
            )}
          </main>
        </div>
      </div>

      {activeSidebarTab === SidebarTab.SETTINGS && (
        <div className="fixed inset-0 z-[1000] modal-overlay p-4">
           <div className="bg-white w-full max-w-2xl rounded-[48px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-gray-100">
              <div className="p-10 border-b border-gray-100 flex items-center justify-between">
                 <div className="flex items-center gap-4">
                    <Palette className="text-[var(--primary)]" />
                    <h3 className="text-sm font-black uppercase tracking-widest">White-Label Branding Engine</h3>
                 </div>
                 <button onClick={() => setActiveSidebarTab(SidebarTab.HOME)} className="p-2 hover:bg-gray-50 rounded-full"><X/></button>
              </div>
              <div className="p-10 space-y-12 max-h-[70vh] overflow-y-auto no-scrollbar">
                 <div className="grid md:grid-cols-2 gap-10">
                    <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Identity Primary</label>
                        <input 
                          type="color" 
                          value={settings.branding.primaryColor} 
                          onChange={e => setSettings({...settings, branding: {...settings.branding, primaryColor: e.target.value}})}
                          className="w-full h-16 rounded-[24px] cursor-pointer overflow-hidden border-4 border-gray-50" 
                        />
                    </div>
                    <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Corporate Backdrop</label>
                        <input 
                          type="color" 
                          value={settings.branding.secondaryColor} 
                          onChange={e => setSettings({...settings, branding: {...settings.branding, secondaryColor: e.target.value}})}
                          className="w-full h-16 rounded-[24px] cursor-pointer overflow-hidden border-4 border-gray-50" 
                        />
                    </div>
                 </div>

                 <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Enterprise Entity Name</label>
                    <input 
                      type="text" 
                      value={settings.branding.companyName} 
                      onChange={e => setSettings({...settings, branding: {...settings.branding, companyName: e.target.value}})}
                      className="w-full bg-gray-50 p-5 rounded-3xl text-sm font-bold border border-gray-100 outline-none focus:ring-2 focus:ring-blue-100" 
                      placeholder="e.g. Acme Corp"
                    />
                 </div>

                 <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Corporate Logo Assets</label>
                    <div className="flex items-center gap-6 p-6 bg-slate-50 border-2 border-dashed border-slate-200 rounded-[32px]">
                       <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center border border-slate-100 overflow-hidden shadow-sm">
                          {settings.branding.logoUrl ? (
                            <img src={settings.branding.logoUrl} className="w-full h-full object-contain" />
                          ) : (
                            <Upload className="text-slate-300" size={24} />
                          )}
                       </div>
                       <div className="flex-1">
                          <input type="file" id="logo-upload" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                          <label htmlFor="logo-upload" className="px-6 py-3 bg-white text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-200 shadow-sm cursor-pointer hover:bg-slate-50 transition-all inline-block">Upload PNG/SVG</label>
                          <p className="text-[9px] text-slate-400 mt-2 font-bold uppercase tracking-widest">Recommended size: 256x256px</p>
                       </div>
                    </div>
                 </div>

                 <button onClick={() => setActiveSidebarTab(SidebarTab.HOME)} className="w-full py-6 bg-slate-900 text-white rounded-[28px] text-[11px] font-black uppercase tracking-widest shadow-2xl hover:bg-black transition-all">Propagate Branding Changes</button>
              </div>
           </div>
        </div>
      )}

      {slides && <PresentationOverlay slides={slides} onClose={() => setSlides(null)} docTitle={docData?.title || 'Untitled Strategic Artifact'} />}
      
      <div className="fixed bottom-8 right-8 z-[2000] flex flex-col gap-4 max-w-sm">
        {toasts.map(t => (
          <div key={t.id} className={`flex flex-col gap-4 px-8 py-8 rounded-[40px] shadow-2xl border-l-8 animate-in slide-in-from-right-20 duration-500 bg-white text-slate-900 ${t.type === 'success' ? 'border-green-500' : 'border-[var(--primary)]'}`}>
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-2xl ${t.type === 'success' ? 'bg-green-50 text-green-600' : 'bg-blue-50 text-blue-600'}`}>
                {t.type === 'success' ? <CheckCircle2 size={24}/> : <Zap size={24}/>}
              </div>
              <div>
                <span className="text-[12px] font-black uppercase tracking-widest leading-relaxed">{t.message}</span>
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">Intelligence Layer Active</p>
              </div>
            </div>
            {t.action && (
              <button onClick={() => { t.action?.(); setToasts(prev => prev.filter(toast => toast.id !== t.id)); }} className="w-full py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:scale-105 transition-all">
                {t.actionLabel || 'Confirm Protocol'}
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const LoadingScreen = () => (
  <div className="h-screen w-screen flex items-center justify-center bg-[#F8F9FA]">
    <div className="flex flex-col items-center gap-6">
      <div className="relative">
        <div className="w-20 h-20 border-4 border-blue-600/10 rounded-full"></div>
        <div className="absolute inset-0 w-20 h-20 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
      <p className="text-[12px] font-black uppercase tracking-[0.6em] text-blue-600 animate-pulse">Initializing Aadvik Enterprise v3.0</p>
    </div>
  </div>
);

export default App;
