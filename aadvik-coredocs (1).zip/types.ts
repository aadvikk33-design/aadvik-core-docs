
export enum SidebarTab {
  HOME = 'HOME',
  HISTORY = 'HISTORY',
  FILES = 'FILES',
  TEMPLATES = 'TEMPLATES',
  AI_IMAGE = 'AI_IMAGE',
  SETTINGS = 'SETTINGS',
  BRANDING = 'BRANDING',
  VAULT = 'VAULT'
}

export type SyncStatus = 'idle' | 'syncing' | 'synced' | 'offline';
export type PageSize = 'A4' | 'Letter' | 'Legal';
export type ThemeColor = 'blue' | 'teal' | 'purple' | 'gold' | 'custom';
export type PresentationTheme = 'corporate' | 'minimalist' | 'creative';

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
  action?: () => void;
  actionLabel?: string;
}

export interface Slide {
  title: string;
  content: string[];
  notes: string;
}

export interface ProofreadResult {
  score: number;
  errors: { original: string; suggestion: string; reason: string }[];
  readability: string;
}

export interface BudgetPrediction {
  category: string;
  predicted: number;
  confidence: number;
  reasoning: string;
}

export interface BrandingSettings {
  logoUrl?: string;
  primaryColor: string;
  secondaryColor: string;
  companyName: string;
}

export interface AppSettings {
  fontFamily: string;
  pageSize: PageSize;
  primaryColor: string;
  showWordCount: boolean;
  enableAIImage: boolean;
  watermark: 'none' | 'draft' | 'confidential' | 'identity';
  darkMode: boolean;
  branding: BrandingSettings;
  isPro: boolean;
  isVaultEnabled: boolean;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  text: string;
  timestamp: any;
}

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  createdBy: string;
  createdAt: any;
}

export interface Activity {
  id: string;
  userName: string;
  action: string;
  timestamp: any;
}

export interface UserPresence {
  uid: string;
  name: string;
  photo: string;
  color: string;
  lastSeen: any;
  cursorPos?: { x: number, y: number };
}

export interface DocumentSession {
  id: string;
  title: string;
  content: string;
  lastActive: any;
  createdBy: string;
  isEncrypted?: boolean;
}
