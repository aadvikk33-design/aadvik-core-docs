
import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Canvas } from './components/Canvas';
import { DocumentState, DocumentSession, SidebarTab } from './types';
import { auth, syncDocumentToCloud, fetchUserDocuments } from './services/firebaseService';
import { onAuthStateChanged, User } from 'firebase/auth';
import { HelpCircle, X } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('theme') === 'dark');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [isTypewriterEnabled, setIsTypewriterEnabled] = useState(false);
  const [activeTab, setActiveTab] = useState<SidebarTab>(SidebarTab.HOME);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced'>('idle');
  const [cloudDocs, setCloudDocs] = useState<any[]>([]);
  const [showHelp, setShowHelp] = useState(false);

  // Multi-Session State
  const [sessions, setSessions] = useState<DocumentSession[]>(() => {
    const saved = localStorage.getItem('aadvik_sessions');
    return saved ? JSON.parse(saved) : [{ id: 'main', title: 'New Manuscript', content: '<h1>Aadvik CoreDocs</h1><p>Start your professional journey.</p>', lastActive: new Date() }];
  });
  const [activeSessionId, setActiveSessionId] = useState('main');

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0];

  useEffect(() => {
    // Fade out splash screen
    const splash = document.getElementById('splash-screen');
    if (splash) {
      setTimeout(() => {
        splash.style.opacity = '0';
        setTimeout(() => splash.style.visibility = 'hidden', 800);
      }, 1500);
    }

    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u) loadCloudDocs(u.uid);
    });

    const handleShortcuts = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === '/') {
        e.preventDefault();
        setShowHelp(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleShortcuts);
    return () => {
      unsubscribe();
      window.removeEventListener('keydown', handleShortcuts);
    };
  }, []);

  const loadCloudDocs = async (uid: string) => {
    try {
      const docs = await fetchUserDocuments(uid);
      setCloudDocs(docs);
    } catch (e) { console.error(e); }
  };

  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  // Persist sessions
  useEffect(() => {
    localStorage.setItem('aadvik_sessions', JSON.stringify(sessions));
  }, [sessions]);

  const updateActiveSession = (data: Partial<DocumentSession>) => {
    setSessions(prev => prev.map(s => s.id === activeSessionId ? { ...s, ...data } : s));
  };

  const createNewSession = () => {
    const id = crypto.randomUUID();
    const newSession = { id, title: 'Untitled Document', content: '<p>New Document</p>', lastActive: new Date() };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(id);
  };

  const closeSession = (id: string) => {
    if (sessions.length === 1) return;
    setSessions(prev => prev.filter(s => s.id !== id));
    if (activeSessionId === id) setActiveSessionId(sessions[0].id);
  };

  // Debounced Cloud Sync
  useEffect(() => {
    if (!user) return;
    const timer = setTimeout(async () => {
      setSyncStatus('syncing');
      try {
        await syncDocumentToCloud(user.uid, activeSessionId, {
          title: activeSession.title,
          content: activeSession.content
        });
        setSyncStatus('synced');
      } catch (e) { setSyncStatus('idle'); }
    }, 2000);
    return () => clearTimeout(timer);
  }, [activeSession.content, activeSession.title, user, activeSessionId]);

  return (
    <div className={`flex h-screen w-screen bg-[var(--bg-app)] text-[var(--text-main)] overflow-hidden transition-all duration-700 ${isFocusMode ? 'focus-mode' : ''}`}>
      {!isFocusMode && (
        <Sidebar 
          user={user}
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
          isCollapsed={isSidebarCollapsed}
          toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          isDarkMode={isDarkMode}
          toggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          isTypewriterEnabled={isTypewriterEnabled}
          toggleTypewriter={() => setIsTypewriterEnabled(!isTypewriterEnabled)}
          sessions={sessions}
          activeSessionId={activeSessionId}
          onSwitchSession={setActiveSessionId}
          onNewSession={createNewSession}
          onCloseSession={closeSession}
        />
      )}
      
      <div className="flex-1 flex flex-col min-w-0">
        {!isFocusMode && (
          <Header 
            title={activeSession.title} 
            onTitleChange={(t) => updateActiveSession({ title: t })}
            content={activeSession.content}
            onUpdateContent={(c) => updateActiveSession({ content: c })}
            isFocusMode={isFocusMode}
            toggleFocus={() => setIsFocusMode(true)}
            onExportJSON={() => {}} // Placeholder
          />
        )}

        <main className="flex-1 overflow-y-auto p-4 md:p-12 flex justify-center no-scrollbar">
          <Canvas 
            content={activeSession.content} 
            onChange={(c) => updateActiveSession({ content: c })} 
            isTypewriterEnabled={isTypewriterEnabled}
            syncStatus={syncStatus}
          />
        </main>
      </div>

      {showHelp && (
        <div className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-white dark:bg-[#1E1E1E] w-full max-w-lg rounded-3xl shadow-2xl border border-[var(--border-color)] overflow-hidden">
            <div className="p-6 border-b border-[var(--border-color)] flex justify-between items-center bg-[#0078D4] text-white">
              <div className="flex items-center gap-3">
                <HelpCircle size={20} />
                <span className="font-black text-xs uppercase tracking-widest">Command Palette</span>
              </div>
              <button onClick={() => setShowHelp(false)}><X size={20} /></button>
            </div>
            <div className="p-8 grid grid-cols-2 gap-6">
              <ShortcutItem keycap="Ctrl + /" label="Help & Shortcuts" />
              <ShortcutItem keycap="Ctrl + B" label="Bold Text" />
              <ShortcutItem keycap="Ctrl + I" label="Italic Text" />
              <ShortcutItem keycap="Ctrl + S" label="Manual Cloud Save" />
              <ShortcutItem keycap="Esc" label="Exit Focus Mode" />
              <ShortcutItem keycap="Tab" label="Toggle Sidebar" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ShortcutItem = ({ keycap, label }: { keycap: string, label: string }) => (
  <div className="flex flex-col gap-1">
    <span className="text-[9px] font-black uppercase opacity-40">{label}</span>
    <kbd className="px-3 py-1 bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-lg text-xs font-mono text-[#0078D4] inline-block">{keycap}</kbd>
  </div>
);

export default App;
