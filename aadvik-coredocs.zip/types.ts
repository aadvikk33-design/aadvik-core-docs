
export enum SidebarTab {
  HOME = 'HOME',
  HISTORY = 'HISTORY',
  FILES = 'FILES',
  SETTINGS = 'SETTINGS'
}

export interface DocumentSession {
  id: string;
  title: string;
  content: string;
  lastActive: Date;
}

export interface HistoryItem {
  id: string;
  timestamp: Date;
  title: string;
  content: string;
}

export interface DocumentState {
  title: string;
  content: string;
  lastSaved: Date;
}
