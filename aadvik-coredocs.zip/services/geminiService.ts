
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
export async function enhanceText(text: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a professional editor. Please improve the clarity, grammar, and style of the following text while maintaining its original meaning. Return ONLY the improved text, no explanations:\n\n${text}`,
    });
    return response.text || text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return text;
  }
}

export async function summarizeText(text: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Summarize the following document content into a concise professional abstract of about 3 sentences:\n\n${text}`,
    });
    return response.text || "Summary generation failed.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating summary.";
  }
}

export async function continueWriting(textBefore: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on the following text, continue the narrative or argument in a professional and seamless way. Provide only the continuation, about 2-3 sentences:\n\n${textBefore}`,
    });
    return response.text || "";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "";
  }
}
