
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { getFirestore, doc, setDoc, collection, query, where, getDocs, Timestamp } from "firebase/firestore";

// REPLACE THESE PLACEHOLDERS WITH YOUR FIREBASE PROJECT CONFIG
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = () => signInWithPopup(auth, googleProvider);
export const logout = () => signOut(auth);

export const syncDocumentToCloud = async (userId: string, docId: string, data: any) => {
  const docRef = doc(db, "users", userId, "documents", docId);
  await setDoc(docRef, {
    ...data,
    lastModified: Timestamp.now()
  }, { merge: true });
};

export const fetchUserDocuments = async (userId: string) => {
  const q = query(collection(db, "users", userId, "documents"));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};
