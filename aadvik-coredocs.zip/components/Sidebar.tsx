
import React from 'react';
import { Home, FolderOpen, History, Moon, Sun, ChevronLeft, Menu, Keyboard, LogIn, LogOut, FileText, Plus, X } from 'lucide-react';
import { SidebarTab, DocumentSession } from '../types';
import { loginWithGoogle, logout } from '../services/firebaseService';
import { User } from 'firebase/auth';

interface SidebarProps {
  user: User | null;
  activeTab: SidebarTab;
  onTabChange: (tab: SidebarTab) => void;
  isCollapsed: boolean;
  toggleCollapse: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  isTypewriterEnabled: boolean;
  toggleTypewriter: () => void;
  sessions: DocumentSession[];
  activeSessionId: string;
  onSwitchSession: (id: string) => void;
  onNewSession: () => void;
  onCloseSession: (id: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  user, activeTab, onTabChange, isCollapsed, toggleCollapse, isDarkMode, toggleDarkMode, isTypewriterEnabled, toggleTypewriter, sessions, activeSessionId, onSwitchSession, onNewSession, onCloseSession
}) => {
  return (
    <aside className={`${isCollapsed ? 'w-16' : 'w-72'} h-full glass-effect border-r border-[var(--border-color)] flex flex-col transition-all duration-500 ease-in-out z-20 no-print`}>
      <div className="p-6 flex items-center justify-between">
        {!isCollapsed && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-[#0078D4] rounded-lg flex items-center justify-center text-white font-black text-[10px] shadow-lg">AD</div>
            <span className="font-black text-xs uppercase tracking-widest opacity-80">AADVIK CORE</span>
          </div>
        )}
        <button onClick={toggleCollapse} className="p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-lg transition-colors">
          {isCollapsed ? <Menu size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>

      <div className="px-3 mb-4">
        {!user ? (
          <button onClick={loginWithGoogle} className="w-full flex items-center justify-center gap-3 p-3 bg-white dark:bg-white/5 border border-[var(--border-color)] rounded-xl hover:bg-gray-50 dark:hover:bg-white/10 transition-all shadow-sm">
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/action/google.svg" className="w-4 h-4" alt="" />
            {!isCollapsed && <span className="text-[10px] font-bold uppercase tracking-widest">Sign In</span>}
          </button>
        ) : (
          <div className={`flex items-center gap-3 ${isCollapsed ? 'justify-center' : 'p-3 bg-blue-500/5 rounded-xl border border-blue-500/10'}`}>
            <img src={user.photoURL || ''} className="w-8 h-8 rounded-full shadow-sm" alt="" />
            {!isCollapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-black truncate">{user.displayName}</p>
                <button onClick={logout} className="text-[8px] text-red-500 font-bold uppercase tracking-widest">Logout</button>
              </div>
            )}
          </div>
        )}
      </div>

      <nav className="flex-1 mt-2 flex flex-col gap-1 px-3 overflow-y-auto no-scrollbar">
        <NavButton active={activeTab === SidebarTab.HOME} onClick={() => onTabChange(SidebarTab.HOME)} icon={Home} label="Dashboard" isCollapsed={isCollapsed} />
        
        <div className="mt-6">
          <div className="flex items-center justify-between px-3 mb-2">
            {!isCollapsed && <h4 className="text-[9px] font-black uppercase tracking-[0.2em] opacity-30">Active Sessions</h4>}
            {!isCollapsed && <button onClick={onNewSession} className="p-1 hover:bg-[#0078D4] hover:text-white rounded-md transition-colors text-blue-500"><Plus size={14}/></button>}
          </div>
          <div className="flex flex-col gap-1">
            {sessions.map((s) => (
              <div key={s.id} className="relative group">
                <button 
                  onClick={() => onSwitchSession(s.id)}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-3 transition-all ${activeSessionId === s.id ? 'bg-blue-500/10 text-blue-600' : 'hover:bg-black/5 dark:hover:bg-white/5 opacity-60 hover:opacity-100'}`}
                >
                  <FileText size={14} />
                  {!isCollapsed && <span className="text-[10px] font-bold truncate max-w-[140px]">{s.title}</span>}
                </button>
                {!isCollapsed && sessions.length > 1 && (
                  <button onClick={(e) => { e.stopPropagation(); onCloseSession(s.id); }} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-600">
                    <X size={12} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </nav>

      <div className="p-4 border-t border-[var(--border-color)] flex flex-col gap-2">
        <button onClick={toggleTypewriter} className={`flex items-center gap-4 p-3 rounded-xl transition-all ${isTypewriterEnabled ? 'text-[#0078D4] bg-blue-500/5' : 'text-gray-400 hover:bg-black/5 dark:hover:bg-white/5'}`}>
          <Keyboard size={18} />
          {!isCollapsed && <span className="text-xs font-semibold">Mechanical Keys</span>}
        </button>
        <button onClick={toggleDarkMode} className="flex items-center gap-4 p-3 rounded-xl text-gray-400 hover:text-[var(--text-main)] hover:bg-black/5 dark:hover:bg-white/5 transition-all">
          {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          {!isCollapsed && <span className="text-xs font-semibold">{isDarkMode ? 'Light' : 'Deep Dark'}</span>}
        </button>
      </div>
    </aside>
  );
};

const NavButton = ({ active, onClick, icon: Icon, label, isCollapsed }: any) => (
  <button onClick={onClick} className={`flex items-center gap-4 p-3 rounded-xl transition-all ${active ? 'bg-[#0078D4] text-white shadow-lg' : 'text-gray-400 hover:text-[var(--text-main)] hover:bg-black/5'}`}>
    <Icon size={18} strokeWidth={active ? 2.5 : 1.5} />
    {!isCollapsed && <span className="text-xs font-bold tracking-wide">{label}</span>}
  </button>
);
