
import React, { useRef, useEffect, useState } from 'react';
import { Sparkles, FileText, FastForward, RotateCcw, Cloud, CheckCircle, RefreshCw } from 'lucide-react';
import { enhanceText, summarizeText, continueWriting } from '../services/geminiService';

interface CanvasProps {
  content: string;
  onChange: (content: string) => void;
  isTypewriterEnabled: boolean;
  syncStatus: 'idle' | 'syncing' | 'synced';
}

export const Canvas: React.FC<CanvasProps> = ({ content, onChange, isTypewriterEnabled, syncStatus }) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const [stats, setStats] = useState({ words: 0, chars: 0, readingTime: 0 });
  const [isAIThinking, setIsAIThinking] = useState(false);
  const [menuPos, setMenuPos] = useState<{ x: number, y: number } | null>(null);
  const [selectedRange, setSelectedRange] = useState<Range | null>(null);

  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== content) {
      editorRef.current.innerHTML = content;
    }
    updateStats(content);
  }, [content]);

  useEffect(() => {
    const handleSelection = () => {
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0 && selection.toString().trim().length > 0) {
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        setSelectedRange(range.cloneRange());
        setMenuPos({ x: rect.left + window.scrollX + (rect.width / 2), y: rect.top + window.scrollY - 10 });
      } else {
        setMenuPos(null);
        setSelectedRange(null);
      }
    };
    document.addEventListener('selectionchange', handleSelection);
    return () => document.removeEventListener('selectionchange', handleSelection);
  }, []);

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const text = e.clipboardData.getData('text/plain');
    document.execCommand('insertText', false, text);
  };

  const playMechanicalClick = () => {
    if (!isTypewriterEnabled) return;
    if (!audioCtxRef.current) audioCtxRef.current = new AudioContext();
    const ctx = audioCtxRef.current;
    if (ctx.state === 'suspended') ctx.resume();
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 0.05, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 2);
    const noise = ctx.createBufferSource(); noise.buffer = buffer;
    const filter = ctx.createBiquadFilter(); filter.type = 'highpass'; filter.frequency.value = 1200;
    const gain = ctx.createGain(); gain.gain.setValueAtTime(0.04, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
    noise.connect(filter); filter.connect(gain); gain.connect(ctx.destination);
    noise.start();
  };

  const updateStats = (html: string) => {
    const text = html.replace(/<[^>]*>/g, '').trim();
    const words = text === "" ? 0 : text.split(/\s+/).length;
    setStats({ words, chars: text.length, readingTime: Math.max(1, Math.ceil(words / 200)) });
  };

  const handleInput = () => {
    if (editorRef.current) {
      const newContent = editorRef.current.innerHTML;
      onChange(newContent);
      updateStats(newContent);
      playMechanicalClick();
    }
  };

  const handleAIAction = async (type: 'rewrite' | 'summarize' | 'continue') => {
    setIsAIThinking(true); setMenuPos(null);
    const selectionText = selectedRange ? selectedRange.toString() : editorRef.current?.innerText || "";
    try {
      let result = "";
      if (type === 'rewrite') result = await enhanceText(selectionText);
      else if (type === 'summarize') result = await summarizeText(selectionText);
      else if (type === 'continue') result = await continueWriting(editorRef.current?.innerText || "");

      if (result && editorRef.current) {
        if (type === 'continue') {
          const p = document.createElement('p'); p.innerText = result; editorRef.current.appendChild(p);
        } else if (selectedRange) {
          selectedRange.deleteContents(); selectedRange.insertNode(document.createTextNode(result));
        }
        onChange(editorRef.current.innerHTML);
      }
    } finally { setIsAIThinking(false); window.getSelection()?.removeAllRanges(); }
  };

  return (
    <div className="relative pb-40">
      {menuPos && (
        <div className="fixed z-50 flex items-center gap-1 bg-white dark:bg-[#1E1E1E] border border-[var(--border-color)] p-1 rounded-xl shadow-2xl glass-effect -translate-x-1/2 -translate-y-full mb-4 animate-in zoom-in duration-200" style={{ left: menuPos.x, top: menuPos.y }}>
          <MenuButton icon={RotateCcw} label="Rewrite" onClick={() => handleAIAction('rewrite')} />
          <MenuButton icon={FileText} label="Summarize" onClick={() => handleAIAction('summarize')} />
          <MenuButton icon={FastForward} label="Continue" onClick={() => handleAIAction('continue')} />
        </div>
      )}

      <div ref={editorRef} contentEditable onInput={handleInput} onPaste={handlePaste} spellCheck={false} className={`a4-page prose prose-slate dark:prose-invert max-w-none transition-all duration-700 focus:ring-0 ${isAIThinking ? 'ai-shimmer pointer-events-none opacity-80' : ''}`} style={{ lineHeight: '1.7', fontSize: '11pt' }} />
      
      <div className="fixed bottom-0 left-0 right-0 h-12 bg-[var(--glass-bg)] glass-effect border-t border-[var(--border-color)] px-10 flex items-center justify-between text-[9px] font-black uppercase tracking-[0.2em] z-40 no-print">
        <div className="flex gap-8 opacity-60">
          <div><span className="text-[var(--primary-blue)]">{stats.words}</span> WORDS</div>
          <div><span className="text-[var(--primary-blue)]">{stats.chars}</span> CHARS</div>
          <div><span className="text-[var(--primary-blue)]">{stats.readingTime} MIN</span> READ</div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {syncStatus === 'syncing' ? (
              <RefreshCw size={12} className="text-blue-500 animate-spin" />
            ) : syncStatus === 'synced' ? (
              <CheckCircle size={12} className="text-green-500" />
            ) : (
              <Cloud size={12} className="text-gray-400" />
            )}
            <span className={syncStatus === 'synced' ? 'text-green-600' : syncStatus === 'syncing' ? 'text-blue-600' : 'text-gray-400'}>
              {syncStatus === 'synced' ? 'Cloud Secured' : syncStatus === 'syncing' ? 'Syncing...' : 'Local Only'}
            </span>
          </div>
          <div className="w-[1px] h-4 bg-[var(--border-color)]" />
          <span className="opacity-50 tracking-tighter">UTF-8 • A4 STANDARD</span>
        </div>
      </div>
    </div>
  );
};

const MenuButton: React.FC<{ icon: any, label: string, onClick: () => void }> = ({ icon: Icon, label, onClick }) => (
  <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); onClick(); }} className="flex items-center gap-2 px-3 py-2 hover:bg-blue-500/10 hover:text-[#0078D4] rounded-lg transition-colors text-[10px] font-bold uppercase tracking-wider text-gray-500">
    <Icon size={14} /><span>{label}</span>
  </button>
);
